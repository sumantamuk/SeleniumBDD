package stepdefinitions;

import framework.controllers.PageFactoryController;
import framework.dependencyinjection.TestContext;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


import java.util.HashMap;
import java.util.List;




public class OrderItemStepDefinition {

    private TestContext testContext;    

    private PageFactoryController pageFactory;

    private static List<HashMap<String, String>> TestData;


    public OrderItemStepDefinition(TestContext testContext)
    {
        this.testContext=testContext;
        pageFactory = testContext.getPageFactoryController();
        TestData = testContext.getFileReaderController().getExcelReader().GetTestData("TestData");        
    }
    
    
    @When("User navigates to {string} screen")
    public void user_navigates_to_screen(String string) {
    	switch(string) {
    	case "T_Shirts":
    		testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lnkTShirts);
    		testContext.getWebElementUtil().commonWaitForElement(pageFactory.getOrderItemPage().lblTshirts);
    	}
    }    
    
    
	@When("User Adds to Cart")
    public void user_Adds_to_Cart() throws InterruptedException {
    	testContext.getWebElementUtil().scrollDown();
    	
    	testContext.getWebElementUtil().mouseHoverElement(pageFactory.getOrderItemPage().lnkItem);
    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lnkAddtoCart);
    	
    	testContext.getWebElementUtil().validateElementExists(pageFactory.getOrderItemPage().lblProductAddtoCart);
    	    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lblProceedToCheckOut);
    	
    	testContext.getWebElementUtil().validateElementExists(pageFactory.getOrderItemPage().lblDeliveryAddress);
    	
    	testContext.getWebElementUtil().validateElementExists(pageFactory.getOrderItemPage().lblInvoiceAddress);
    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lblCartProceedToCheckOut);
    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lblCartProceedToCheckOut);
    	    	
    	testContext.getWebElementUtil().selectCheckBox(pageFactory.getOrderItemPage().chkAgreeTermsofService);
    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lblCartProceedToCheckOut);
    	
    	
    }
    
    @Then("User completes Payment")
    public void user_completes_Payment() {
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lnkPayByBank);
    	
    	testContext.getWebElementUtil().commonClick(pageFactory.getOrderItemPage().lblConfirmOrder);
    	
    	testContext.getWebElementUtil().validateElementExists(pageFactory.getOrderItemPage().lblOrderCompleted);

    }
}

