package stepdefinitions;

import framework.controllers.PageFactoryController;
import framework.dependencyinjection.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import java.util.HashMap;
import java.util.List;
import org.junit.Assert;


public class RegistrationStepDefinition {

    private TestContext testContext;

    private PageFactoryController pageFactory;

    private List<HashMap<String, String>> TestData;


    public RegistrationStepDefinition(TestContext testContext)
    {
        this.testContext=testContext;
        pageFactory = testContext.getPageFactoryController();
        TestData = testContext.getFileReaderController().getExcelReader().GetTestData("TestData");
    }

    @Then("User Registers in My Store")
    public void user_Registers_in_My_Store() {
    	try {
		    	String strGender=TestData.get(LoginStepDefinition.index).get("Gender");
		    	if (strGender.equalsIgnoreCase("Mr")) {
		    		testContext.getWebElementUtil().commonClick(pageFactory.getRegistrationPage().rdoTitleMr);
		    	}
		    	else {
		    		testContext.getWebElementUtil().commonClick(pageFactory.getRegistrationPage().rdoTitleMrs);
		    	}
		    	
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtCustomerFirstName,TestData.get(LoginStepDefinition.index).get("FirstName"));
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtCustomerLastName,TestData.get(LoginStepDefinition.index).get("LastName"));
		    	
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtPassword,TestData.get(LoginStepDefinition.index).get("Password"));
		    	
		    	testContext.getWebElementUtil().commonSelectDropdown(pageFactory.getRegistrationPage().lstDate, TestData.get(LoginStepDefinition.index).get("DayOfBirth")+"  ");
		    	testContext.getWebElementUtil().commonSelectDropdown(pageFactory.getRegistrationPage().lstMonth, TestData.get(LoginStepDefinition.index).get("MonthOfBirth")+" ");
		    	testContext.getWebElementUtil().commonSelectDropdown(pageFactory.getRegistrationPage().lstYear, TestData.get(LoginStepDefinition.index).get("YearOfBirth")+"  ");		    	
		    	
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtCompany,TestData.get(LoginStepDefinition.index).get("Company"));
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtAddress1,TestData.get(LoginStepDefinition.index).get("Address1"));
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtCity,TestData.get(LoginStepDefinition.index).get("City"));
		    	
		    	testContext.getWebElementUtil().commonSelectDropdown(pageFactory.getRegistrationPage().lstCountry, TestData.get(LoginStepDefinition.index).get("Country"));
		    	testContext.getWebElementUtil().commonSelectDropdown(pageFactory.getRegistrationPage().lstState, TestData.get(LoginStepDefinition.index).get("State"));
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtPostCode,TestData.get(LoginStepDefinition.index).get("ZipCode"));
		    	
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtMobile,TestData.get(LoginStepDefinition.index).get("Mobile"));
		    	testContext.getWebElementUtil().commonSendTestData(pageFactory.getRegistrationPage().txtAddressAlias,TestData.get(LoginStepDefinition.index).get("AddressAlias"));
		    	
		    	testContext.getWebElementUtil().commonClick(pageFactory.getRegistrationPage().btnRegister);
          	}
    	catch(Exception e) {
    		Assert.fail(e.getMessage());
    	}

    }
    
    @Given("Validate myAccount is displayed")
    public void validate_myAccount_is_disyplayed() {
    	try {
    		testContext.getWebElementUtil().commonWaitForElement(pageFactory.getRegistrationPage().lblMyAccount);	
    	}
        catch(Exception e) {
        	Assert.fail(e.getMessage());
        }
    }
}

