package stepdefinitions;

import framework.controllers.PageFactoryController;
import framework.dataprovider.CommonMethods;
import framework.dependencyinjection.TestContext;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;

import java.util.HashMap;
import java.util.List;
import org.junit.Assert;


public class LoginStepDefinition {

    private TestContext testContext;

    private PageFactoryController pageFactory;

    private List<HashMap<String, String>> TestData;
    
	public static int index=0;

    public LoginStepDefinition(TestContext testContext)
    {
        this.testContext=testContext;
        pageFactory = testContext.getPageFactoryController();
        TestData = testContext.getFileReaderController().getExcelReader().GetTestData("TestData");
    }

    @Given("Login as a User for {string}")
    public void login_as_a_User_for(String testData)
    {
        try
        {
        	String numberOnly = testData.replaceAll("[^0-9]", "");
            index = Integer.parseInt(numberOnly) - 1;
            int rndNum=new CommonMethods().generateRandomNumber();
            String[] arrSplit = TestData.get(index).get("EmailID").split("@");
            
            testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().lnkSignIn);
            testContext.getWebElementUtil().commonClick(pageFactory.getHomepage().lnkSignIn);
            testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().txtEmailCreate);
            
            testContext.getWebElementUtil().commonSendTestData(pageFactory.getHomepage().txtEmailCreate, arrSplit[0]+String.valueOf(rndNum)+"@"+arrSplit[1]);
            testContext.getWebElementUtil().commonClick(pageFactory.getHomepage().btnSubmitCreateAccount);
        }
        catch (AssertionError | Exception e)
        {
            e.printStackTrace();
            Assert.fail(e.getMessage());
        }

    }

    @When("Validate the presence of Registration Page")
    public void VerifyUserRegistrationPage()
    {
        try
        {
        	testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().pgRegistration);
        }
        catch (AssertionError | Exception e)
        {
            e.printStackTrace();
            Assert.fail();
        }

    }
    
    @Given("Validate Invalid Login credentials")
    public void validate_invalid_login_credentials() {
    	try {
    		testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().errAuthenticationFailed);	
    	}
        catch(Exception e) {
        	Assert.fail(e.getMessage());
        }
    }
    
    @Given("Login to Mystore {string}")
    public void Login_to_Mystore(String testData)
    {
        try
        {
        	String numberOnly = testData.replaceAll("[^0-9]", "");
            index = Integer.parseInt(numberOnly) - 1;            
            
            testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().lnkSignIn);
            testContext.getWebElementUtil().commonClick(pageFactory.getHomepage().lnkSignIn);
            testContext.getWebElementUtil().commonWaitForElement(pageFactory.getHomepage().txtSignInEmail);
            
            testContext.getWebElementUtil().commonSendTestData(pageFactory.getHomepage().txtSignInEmail, TestData.get(index).get("EmailID"));
            testContext.getWebElementUtil().commonSendTestData(pageFactory.getHomepage().txtSignInPassword, TestData.get(index).get("Password"));
            testContext.getWebElementUtil().commonClick(pageFactory.getHomepage().btnSignIn);
        }
        catch (AssertionError | Exception e)
        {            
            Assert.fail(e.getMessage());
        }

    }
    



}
