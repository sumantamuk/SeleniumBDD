package pagefactory;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class OrderItem {

    @FindBy(xpath = "//ul[@class=\"sf-menu clearfix menu-content sf-js-enabled sf-arrows\"]/li/a[text()='T-shirts']")
    public WebElement lnkTShirts;

    @FindBy(xpath = "//span[@class='cat-name' and contains(text(),'T-shirts')]")
    public WebElement lblTshirts;
    
    @FindBy(xpath = "//a[@class='product_img_link' and @title='Faded Short Sleeve T-shirts']/../../..//a[@title='Add to cart']")
    public WebElement lnkAddtoCart;
    
    @FindBy(xpath = "//a[@class='product_img_link' and @title='Faded Short Sleeve T-shirts']")
    public WebElement lnkItem;
    
    @FindBy(xpath = "//div[@class='layer_cart_product col-xs-12 col-md-6']//h2")
    public WebElement lblProductAddtoCart;
    
    @FindBy(xpath = "//span[contains(text(),'Proceed to checkout')]")
    public WebElement lblProceedToCheckOut;
    
    @FindBy(xpath = "//h3[contains(text(),'Delivery address')]")
    public WebElement lblDeliveryAddress;
    
    @FindBy(xpath = "//h3[contains(text(),'Invoice address')]")
    public WebElement lblInvoiceAddress;
    
    @FindBy(xpath = "//p[@class='cart_navigation clearfix']//span[contains(text(),'Proceed to checkout')]")
    public WebElement lblCartProceedToCheckOut;
        
    public By chkAgreeTermsofService=By.xpath("//input[@id='cgv']");
  
    @FindBy(xpath = "//a[@title='Pay by bank wire']")
    public WebElement lnkPayByBank;
    
    @FindBy(xpath = "//span[text()='I confirm my order']")
    public WebElement lblConfirmOrder;
    
    @FindBy(xpath = "//strong[text()='Your order on My Store is complete.']")
    public WebElement lblOrderCompleted;
  
  
}
