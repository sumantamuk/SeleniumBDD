package pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class RegistrationPage {

    @FindBy(xpath = "//input[@id='id_gender1']")
    public WebElement rdoTitleMr;

    @FindBy(xpath = "//input[@id='id_gender1']")
    public WebElement rdoTitleMrs;
    
    @FindBy(xpath = "//input[@id='customer_firstname']")
    public WebElement txtCustomerFirstName;
    
    @FindBy(xpath = "//input[@id='customer_lastname']")
    public WebElement txtCustomerLastName;
    
    @FindBy(xpath = "//input[@id='passwd']")
    public WebElement txtPassword;
    
    @FindBy(xpath = "//select[@id='days']")
    public WebElement lstDate;
    
    @FindBy(xpath = "//select[@id='months']")
    public WebElement lstMonth;
    
    @FindBy(xpath = "//select[@id='years']")
    public WebElement lstYear;
    
    @FindBy(xpath = "//input[@id='company']")
    public WebElement txtCompany;
    
    @FindBy(xpath = "//input[@id='address1']")
    public WebElement txtAddress1;
    
    @FindBy(xpath = "//input[@id='city']")
    public WebElement txtCity;
    
    @FindBy(xpath = "//select[@id='id_state']")
    public WebElement lstState;
    
    @FindBy(xpath = "//input[@id='postcode']")
    public WebElement txtPostCode;
    
    @FindBy(xpath = "//select[@id='id_country']")
    public WebElement lstCountry;
    
    @FindBy(xpath = "//input[@id='phone_mobile']")
    public WebElement txtMobile;
    
    @FindBy(xpath = "//input[@id='alias']")
    public WebElement txtAddressAlias;
    
    @FindBy(xpath = "//button[@id='submitAccount']")
    public WebElement btnRegister;
    
    @FindBy(xpath = "//h1[text()='My account']")
    public WebElement lblMyAccount;
  
}
