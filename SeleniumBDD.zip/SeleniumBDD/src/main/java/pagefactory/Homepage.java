package pagefactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;


public class Homepage {

    @FindBy(xpath = "//a[contains(text(), 'Sign in')]")
    public WebElement lnkSignIn;

    @FindBy(xpath = "//button[@id='SubmitCreate']")
    public WebElement btnSubmitCreateAccount;
    
    @FindBy(xpath = "//input[@type='text' and @name='email_create']")
    public WebElement txtEmailCreate;
    
    @FindBy(xpath = "//label[text()='Email address']/following-sibling::input[@name='email']")
    public WebElement txtSignInEmail;
    
    @FindBy(xpath = "//input[@name='passwd']")
    public WebElement txtSignInPassword;
    
    @FindBy(xpath = "//button[@id='SubmitLogin']")
    public WebElement btnSignIn;
    
    @FindBy(xpath = "//h3[text()='Your personal information']")
    public WebElement pgRegistration;
    
    @FindBy(xpath = "//li[text()='Authentication failed.']")
    public WebElement errAuthenticationFailed;
    

}
