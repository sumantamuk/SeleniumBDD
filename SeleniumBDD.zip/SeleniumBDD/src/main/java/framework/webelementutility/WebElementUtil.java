package framework.webelementutility;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;


public class WebElementUtil {

    
    private WebDriver driver;

    public WebElementUtil(WebDriver driver) {

        this.driver=driver;
    }
    
    public void commonWaitForElement(WebElement element) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.elementToBeClickable(element));
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }

    public void commonClick(WebElement element) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.elementToBeClickable(element));
                element.click();
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }

    public void commonSendTestData(WebElement element, String testData) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.elementToBeClickable(element));
                element.sendKeys(testData);
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }

    public void commonSelectDropdown(WebElement element, String testData) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
            	Select selectdropdown = new Select(element);                
                selectdropdown.selectByVisibleText(testData);                
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }
    
    public void scrollDown() {
    	JavascriptExecutor js = (JavascriptExecutor) driver;
    	js.executeScript("window.scrollBy(0,700)", "");
    }
    
    public void mouseHoverElement(WebElement element) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
            	Actions action = new Actions(driver);            	
            	action.moveToElement(element).perform();
            	break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }
    
    public void validateElementExists(WebElement element) {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
                WebDriverWait wait = new WebDriverWait(driver, 20);
                wait.until(ExpectedConditions.elementToBeClickable(element));
                if (element.isDisplayed()){
                	System.out.println("Element Exists");
                }
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
                counter++;
            }
        }
    }
    
    public void selectCheckBox(By xPath) throws InterruptedException {

        int counter = 0;
        while(counter<=5)
        {
            try
            {
            	driver.navigate().refresh();
            	Thread.sleep(5000);
            	retryingFindClick(xPath);
                break;
            }
            catch (org.openqa.selenium.StaleElementReferenceException | org.openqa.selenium.ElementNotInteractableException e)
            {
            	driver.navigate().refresh();
            	Thread.sleep(5000);
            	retryingFindClick(xPath);
            	counter++;
            }
        }
    }
        
    public boolean retryingFindClick(By by) {
        boolean result = false;
        int attempts = 0;
        while(attempts < 2) {
            try {
                driver.findElement(by).click();
                result = true;
                break;
            } catch(NoSuchElementException e) {
            }
            attempts++;
        }
        return result;
    }
    
}
