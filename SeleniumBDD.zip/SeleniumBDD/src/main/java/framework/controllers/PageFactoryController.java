package framework.controllers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import pagefactory.Homepage;
import pagefactory.OrderItem;
import pagefactory.RegistrationPage;

public class PageFactoryController {

    private WebDriver driver;

    public PageFactoryController(WebDriver driver) {

        this.driver=driver;
    }

    public Homepage getHomepage() {        
        return PageFactory.initElements(driver, Homepage.class);
    }
    
    public RegistrationPage getRegistrationPage() {        
        return PageFactory.initElements(driver, RegistrationPage.class);
    }
    
    public OrderItem getOrderItemPage() {
    	return PageFactory.initElements(driver, OrderItem.class);
    }
}
